import {
  DefaultAmplify
} from "./chunk-UN6RSTMY.js";
import "./chunk-XI26FZXZ.js";
import "./chunk-Z3PMQDNO.js";
import "./chunk-XSJ22537.js";
import "./chunk-N2XVWGRC.js";
import "./chunk-RM45IPHL.js";
export {
  DefaultAmplify as Amplify
};
//# sourceMappingURL=aws-amplify.js.map
