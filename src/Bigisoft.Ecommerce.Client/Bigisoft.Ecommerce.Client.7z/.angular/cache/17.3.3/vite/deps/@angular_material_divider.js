import {
  MatDivider,
  MatDividerModule
} from "./chunk-5OJFNB3E.js";
import "./chunk-LNQRPFBG.js";
import "./chunk-R273PTQV.js";
import "./chunk-56V4QARE.js";
import "./chunk-4CZTBPIC.js";
import "./chunk-HL76CS3S.js";
import "./chunk-XSJ22537.js";
import "./chunk-N2XVWGRC.js";
import "./chunk-RM45IPHL.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
