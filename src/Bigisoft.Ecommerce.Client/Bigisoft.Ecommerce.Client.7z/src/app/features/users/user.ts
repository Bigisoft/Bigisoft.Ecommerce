export interface User {
  email: string;
  username: string;
  password: string;
  givenName: string;

  familyName: string;
  code: string;
  showPassword: boolean;
}
