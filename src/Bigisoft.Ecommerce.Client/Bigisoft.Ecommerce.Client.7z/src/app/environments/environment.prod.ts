
export const environment = {
  production: true,
  //apiEndpoint: 'http://localhost:3000',
  cognito: {
    region: "eu-central-1",
    userPoolId: 'eu-central-1_fjjKslxbQ',
    userPoolClientId: '1evh1p0lsvhu84nrmvbj0tr383',
    userPoolClientSecret: 'ij9u55hs4v7q0b8mpsp702v1p9mctsojs3hort03cetk4mkicgs'
  },
};

